package com.example.nowrinshop.repository;

import com.example.nowrinshop.entity.Invoice;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class InvoiceRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Invoice> invoiceRowMapper = (rs, rowNum) -> {
        Invoice invoice = new Invoice();
        invoice.setId(rs.getInt("id"));
        invoice.setOrderId(rs.getInt("order_id"));
        invoice.setInvoiceDetails(rs.getString("invoice_details"));
        return invoice;
    };

    public InvoiceRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    public Optional<Invoice> findById(int id) {
        String sql = "SELECT * FROM invoices WHERE id = ?";
        return jdbcTemplate.query(sql, invoiceRowMapper, id).stream().findFirst();
    }


    public Optional<Invoice> findByOrderId(int orderId) {
        String sql = "SELECT * FROM invoices WHERE order_id = ?";
        return jdbcTemplate.query(sql, invoiceRowMapper, orderId).stream().findFirst();
    }


    public void save(Invoice invoice) {
        String sql = "INSERT INTO invoices (order_id, invoice_details) VALUES (?, ?)";
        jdbcTemplate.update(sql, invoice.getOrderId(), invoice.getInvoiceDetails());
    }
}
