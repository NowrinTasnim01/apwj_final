package com.example.nowrinshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class nowrinshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(nowrinshopApplication.class, args);
	}

}
