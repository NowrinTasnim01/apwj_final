package com.example.nowrinshop.service;

import com.example.nowrinshop.entity.CartItem;
import com.example.nowrinshop.repository.CartRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    private final CartRepository cartRepository;

    public CartService(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }


    public List<CartItem> getCartByUserId(int userId) {
        return cartRepository.findByUserId(userId);
    }


    public void addToCart(CartItem item) {
        cartRepository.add(item);
    }


    public void updateCartItemQuantity(int cartItemId, int quantity) {
        cartRepository.updateQuantity(cartItemId, quantity);
    }


    public void removeFromCart(int cartItemId) {
        cartRepository.remove(cartItemId);
    }


    public void clearCart(int userId) {
        cartRepository.clearCart(userId);
    }
}
