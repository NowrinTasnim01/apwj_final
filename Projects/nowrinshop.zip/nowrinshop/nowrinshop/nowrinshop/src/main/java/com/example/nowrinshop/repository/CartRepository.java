package com.example.nowrinshop.repository;

import com.example.nowrinshop.entity.CartItem;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CartRepository  {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<CartItem> cartRowMapper = (rs, rowNum) -> {
        CartItem item = new CartItem();
        item.setId(rs.getInt("id"));
        item.setUserId(rs.getInt("user_id"));
        item.setProductId(rs.getInt("product_id"));
        item.setQuantity(rs.getInt("quantity"));
        return item;
    };

    public CartRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    public List<CartItem> findByUserId(int userId) {
        String sql = "SELECT * FROM cart_items WHERE user_id = ?";
        return jdbcTemplate.query(sql, cartRowMapper, userId);
    }


    public void add(CartItem item) {
        String sql = "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, item.getUserId(), item.getProductId(), item.getQuantity());
    }


    public void updateQuantity(int id, int quantity) {
        String sql = "UPDATE cart_items SET quantity = ? WHERE id = ?";
        jdbcTemplate.update(sql, quantity, id);
    }


    public void remove(int id) {
        String sql = "DELETE FROM cart_items WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }


    public void clearCart(int userId) {
        String sql = "DELETE FROM cart_items WHERE user_id = ?";
        jdbcTemplate.update(sql, userId);
    }
}
