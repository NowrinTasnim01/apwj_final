package com.example.nowrinshop.service;

import com.example.nowrinshop.entity.Product;
import com.example.nowrinshop.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService  {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }


    public Optional<Product> findById(int id) {
        return productRepository.findById(id);
    }


    public List<Product> findAll() {
        return productRepository.findAll();
    }


    public List<Product> findByCategory(String category) {
        return productRepository.findByCategory(category);
    }


    public List<Product> findExpiringWithinDays(int days) {
        return productRepository.findExpiringWithinDays(days);
    }


    public List<Product> findExpired() {
        return productRepository.findExpired();
    }


    public void save(Product product) {
        productRepository.save(product);
    }


    public void update(Product product) {
        productRepository.update(product);
    }


    public void deleteById(int id) {
        productRepository.deleteById(id);
    }
}
