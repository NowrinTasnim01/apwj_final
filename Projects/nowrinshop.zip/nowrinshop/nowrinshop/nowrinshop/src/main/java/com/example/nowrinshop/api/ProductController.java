package com.example.nowrinshop.api;

import com.example.nowrinshop.entity.Product;
import com.example.nowrinshop.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // ADMIN only - Add product
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<String> addProduct(@RequestBody Product product) {
        productService.save(product);
        return ResponseEntity.ok("Product added successfully");
    }

    // ADMIN only - Bulk add
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/bulk")
    public ResponseEntity<String> addBulkProducts(@RequestBody List<Product> products) {
        products.forEach(productService::save);
        return ResponseEntity.ok("Bulk products added successfully");
    }

    // ADMIN only - Update product
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<String> updateProduct(@PathVariable int id, @RequestBody Product product) {
        product.setId(id);
        productService.update(product);
        return ResponseEntity.ok("Product updated successfully");
    }

    // ADMIN only - Delete product
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable int id) {
        productService.deleteById(id);
        return ResponseEntity.ok("Product deleted successfully");
    }

    // All users - List all products
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(productService.findAll());
    }

    // All users - List products by category
    @GetMapping("/category/{category}")
    public ResponseEntity<List<Product>> getByCategory(@PathVariable String category) {
        return ResponseEntity.ok(productService.findByCategory(category));
    }

    // Show products expiring within 7 days with discount applied
    @GetMapping("/expiring-soon")
    public ResponseEntity<List<Product>> getExpiringSoonProducts() {
        List<Product> products = productService.findExpiringWithinDays(7);
        products.forEach(p -> {
            if (p.getDiscount() == null) {
                p.setDiscount(20.0); // 20% discount
            }
        });
        return ResponseEntity.ok(products);
    }

    // Show expired products (marked unavailable)
    @GetMapping("/expired")
    public ResponseEntity<List<Product>> getExpiredProducts() {
        return ResponseEntity.ok(productService.findExpired());
    }
}
