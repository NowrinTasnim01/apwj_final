package com.example.nowrinshop.service;

import com.example.nowrinshop.entity.WishlistItem;
import com.example.nowrinshop.repository.WishlistRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WishlistService  {

    private final WishlistRepository wishlistRepository;

    public WishlistService(WishlistRepository wishlistRepository) {
        this.wishlistRepository = wishlistRepository;
    }


    public List<WishlistItem> getWishlistByUserId(int userId) {
        return wishlistRepository.findByUserId(userId);
    }


    public void addToWishlist(WishlistItem item) {
        wishlistRepository.add(item);
    }


    public void removeFromWishlist(int id) {
        wishlistRepository.remove(id);
    }
}