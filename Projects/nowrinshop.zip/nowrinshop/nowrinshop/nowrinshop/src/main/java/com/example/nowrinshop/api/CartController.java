package com.example.nowrinshop.api;

import com.example.nowrinshop.entity.CartItem;
import com.example.nowrinshop.service.CartService;
import com.example.nowrinshop.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;
    private final UserService userService;

    public CartController(CartService cartService, UserService userService) {
        this.cartService = cartService;
        this.userService = userService;
    }

    // Get cart items for logged-in user
    @GetMapping
    public ResponseEntity<List<CartItem>> getCart(@AuthenticationPrincipal UserDetails userDetails) {
        String username = userDetails.getUsername();
        int userId = userService.findByUsername(username).orElseThrow().getId();
        List<CartItem> items = cartService.getCartByUserId(userId);
        return ResponseEntity.ok(items);
    }

    // Add item to cart
    @PostMapping
    public ResponseEntity<String> addToCart(@AuthenticationPrincipal UserDetails userDetails,
                                            @RequestBody CartItem item) {
        String username = userDetails.getUsername();
        int userId = userService.findByUsername(username).orElseThrow().getId();
        item.setUserId(userId);
        cartService.addToCart(item);
        return ResponseEntity.ok("Item added to cart");
    }

    // Update cart item quantity
    @PutMapping("/{cartItemId}")
    public ResponseEntity<String> updateQuantity(@PathVariable int cartItemId,
                                                 @RequestBody int quantity) {
        cartService.updateCartItemQuantity(cartItemId, quantity);
        return ResponseEntity.ok("Quantity updated");
    }

    // Remove item from cart
    @DeleteMapping("/{cartItemId}")
    public ResponseEntity<String> removeFromCart(@PathVariable int cartItemId) {
        cartService.removeFromCart(cartItemId);
        return ResponseEntity.ok("Item removed from cart");
    }

    // Clear cart
    @DeleteMapping("/clear")
    public ResponseEntity<String> clearCart(@AuthenticationPrincipal UserDetails userDetails) {
        String username = userDetails.getUsername();
        int userId = userService.findByUsername(username).orElseThrow().getId();
        cartService.clearCart(userId);
        return ResponseEntity.ok("Cart cleared");
    }
}
