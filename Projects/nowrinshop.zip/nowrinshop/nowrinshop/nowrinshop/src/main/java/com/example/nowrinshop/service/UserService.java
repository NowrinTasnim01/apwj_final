package com.example.nowrinshop.service;

import com.example.nowrinshop.entity.User;
import com.example.nowrinshop.repository.UserRepository;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserService  {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JavaMailSender mailSender;

    public UserService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder, JavaMailSender mailSender) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.mailSender = mailSender;
    }


    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }


    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }


    public void registerUser(User user) {
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("USER");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
    }


    public void updatePassword(int userId, String newPassword) {
        String encoded = passwordEncoder.encode(newPassword);
        userRepository.updatePassword(userId, encoded);
    }


    public Optional<User> findById(int id) {
        return userRepository.findById(id);
    }

    public Optional<User> findByResetToken(String token) {
        return userRepository.findByResetToken(token);
    }


    public void updateResetToken(int userId, String token, LocalDateTime expiry) {
        userRepository.updateResetToken(userId, token, expiry);
    }


    public void clearResetToken(int userId) {
        userRepository.clearResetToken(userId);
    }

    public void sendForgotPasswordEmail(String toEmail, String resetLink) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Password Reset Request");
        message.setText("Click the link to reset your password: " + resetLink);
        mailSender.send(message);
    }

}
