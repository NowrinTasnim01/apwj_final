package com.example.nowrinshop.repository;

import com.example.nowrinshop.entity.Product;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ProductRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Product> productRowMapper = (rs, rowNum) -> {
        Product p = new Product();
        p.setId(rs.getInt("id"));
        p.setName(rs.getString("name"));
        p.setCategory(rs.getString("category"));
        p.setPrice(rs.getDouble("price"));
        p.setQuantity(rs.getInt("quantity"));
        p.setExpiryDate(rs.getDate("expiry_date"));
        return p;
    };

    public ProductRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    public Optional<Product> findById(int id) {
        String sql = "SELECT * FROM products WHERE id = ?";
        return jdbcTemplate.query(sql, productRowMapper, id).stream().findFirst();
    }


    public List<Product> findAll() {
        String sql = "SELECT * FROM products";
        return jdbcTemplate.query(sql, productRowMapper);
    }


    public List<Product> findByCategory(String category) {
        String sql = "SELECT * FROM products WHERE category = ?";
        return jdbcTemplate.query(sql, productRowMapper, category);
    }


    public List<Product> findExpiringWithinDays(int days) {
        String sql = "SELECT * FROM products WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)";
        return jdbcTemplate.query(sql, productRowMapper, days);
    }


    public List<Product> findExpired() {
        String sql = "SELECT * FROM products WHERE expiry_date < CURDATE()";
        return jdbcTemplate.query(sql, productRowMapper);
    }


    public void save(Product product) {
        String sql = "INSERT INTO products (name, category, price, quantity, expiry_date) VALUES (?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, product.getName(), product.getCategory(), product.getPrice(), product.getQuantity(), product.getExpiryDate());
    }


    public void update(Product product) {
        String sql = "UPDATE products SET name = ?, category = ?, price = ?, quantity = ?, expiry_date = ? WHERE id = ?";
        jdbcTemplate.update(sql, product.getName(), product.getCategory(), product.getPrice(), product.getQuantity(), product.getExpiryDate(), product.getId());
    }


    public void deleteById(int id) {
        String sql = "DELETE FROM products WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }

    public List<String> getBestSellingProducts(int year, int month) {
        String sql = "SELECT p.name, SUM(oi.quantity) AS total_quantity " +
                "FROM orders o " +
                "JOIN order_items oi ON o.id = oi.order_id " +
                "JOIN products p ON oi.product_id = p.id " +
                "WHERE YEAR(o.order_date) = ? AND MONTH(o.order_date) = ? " +
                "GROUP BY p.name " +
                "ORDER BY total_quantity DESC " +
                "LIMIT 5";

        return jdbcTemplate.query(sql, new Object[]{year, month},
                (rs, rowNum) -> rs.getString("name"));
    }
}
