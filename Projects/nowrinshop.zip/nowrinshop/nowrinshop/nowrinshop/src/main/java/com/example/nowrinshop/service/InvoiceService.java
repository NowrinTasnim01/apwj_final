package com.example.nowrinshop.service;

import com.example.nowrinshop.entity.Invoice;
import com.example.nowrinshop.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InvoiceService  {

    private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }


    public Optional<Invoice> findById(int id) {
        return invoiceRepository.findById(id);
    }


    public Optional<Invoice> findByOrderId(int orderId) {
        return invoiceRepository.findByOrderId(orderId);
    }


    public void generateInvoice(Invoice invoice) {
        invoiceRepository.save(invoice);
    }
}
