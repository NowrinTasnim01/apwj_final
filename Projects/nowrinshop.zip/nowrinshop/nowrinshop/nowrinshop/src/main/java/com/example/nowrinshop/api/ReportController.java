package com.example.nowrinshop.api;

import com.example.nowrinshop.dto.MonthlySalesReportDTO;
import com.example.nowrinshop.service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
@CrossOrigin
@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/monthly-sales")
    public ResponseEntity<MonthlySalesReportDTO> getMonthlySalesReport(
            @RequestParam int year,
            @RequestParam int month) {
        MonthlySalesReportDTO report = reportService.generateMonthlySalesReport(year, month);
        return ResponseEntity.ok(report);
    }
}
