package com.example.nowrinshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
